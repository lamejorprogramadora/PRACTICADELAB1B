﻿Public Class Form1
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim a As String
        Dim b As String
        Dim c As String
        Dim d As String
        a = Convert.ToDouble(TextBox1.Text)
        b = Convert.ToDouble(TextBox2.Text)
        c = Convert.ToDouble(TextBox3.Text)
        d = Convert.ToDouble(TextBox4.Text)
        TextBox5.Text = (Convert.ToDouble(a) + Convert.ToDouble(b) + Convert.ToDouble(c) + Convert.ToDouble(d)) / 4

    End Sub
End Class
