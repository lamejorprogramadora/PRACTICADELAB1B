﻿Public Class Form1
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim X As String
        X = TextBox1.Text
        If (X > 1) Then
            TextBox2.Text = " POSITIVO "

        End If

        If (X = 0) Then
            TextBox2.Text = "NEGATIVO"

        End If
        If (X = 0) Then
            TextBox2.Text = "NULO"

        End If
    End Sub
End Class
