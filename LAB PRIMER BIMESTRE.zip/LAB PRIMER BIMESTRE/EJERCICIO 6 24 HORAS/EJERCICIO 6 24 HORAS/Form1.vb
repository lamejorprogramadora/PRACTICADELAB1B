﻿Public Class Form1
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click

        Me.TextBox1.Text = Now.ToString("HH")
        If (TextBox1.Text > 1) And (TextBox1.Text < 11) Then
            Me.TextBox2.Text = Now.ToString("hh") & " a.m"
        End If
        If (TextBox1.Text > 12) And (TextBox1.Text < 25) Then
            Me.TextBox2.Text = Now.ToString("hh") & " a.m"
        End If





    End Sub

    Private Sub Label2_Click(sender As Object, e As EventArgs) Handles Label2.Click

    End Sub
End Class
