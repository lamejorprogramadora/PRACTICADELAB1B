﻿Public Class estudiante
    'herencia'
    Inherits persona
    'atributo'
    Private _tipodecontrato As String
    Private _sueldo As Double
    Public Property Tipodecontrato As String
        Get
            Return _tipodecontrato
        End Get
        Set(value As String)
            _tipodecontrato = value
        End Set
    End Property
    Public Property Sueldo As Double
        Get
            Return _sueldo
        End Get
        Set(value As Double)
            _sueldo = value
        End Set
    End Property

    'operacion'
    Public Sub calcularsueldo(sueldobase As Double)
        If (Me.Tipodecontrato = "Contratado") Then
            Me.Sueldo = sueldobase + 300
        ElseIf (Me.Tipodecontrato = "Nombrado") Then
            Me.Sueldo = sueldobase + 500
        Else
            Me.Sueldo = 0
        End If
    End Sub


End Class
