﻿Public Class profesor
    'herencia'
    Inherits persona
    'atributo'
    Private _categoria As String
    Private _codigo As String
    'propiedades'
    Public Property Categoria As String
        Get
            Return _categoria
        End Get
        Set(value As String)
            _categoria = value
        End Set
    End Property
    Public Property Codigo As String
        Get
            Return _codigo
        End Get
        Set(value As String)
            _codigo = value
        End Set
    End Property

    Public Sub generarCodigo()
        Me.Codigo = "Contratado" & Me.Apellido.Substring(0, 3) & "its"
    End Sub
End Class
