﻿
Public Class Form1
    Private Sub Label1_Click(sender As Object, e As EventArgs) Handles Label1.Click

    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim empleado1 As estudiante = New estudiante()
        empleado1.Nombres = TextBox1.Text
        empleado1.Apellido = TextBox3.Text
        empleado1.Tipo = ComboBox1.Text
        empleado1.Tipodecontrato = ComboBox2.Text
        empleado1.calcularsueldo(3000)
        DataGridView1.Rows.Insert(0, empleado1.Tipo,
                                    empleado1.Nombres,
                                    empleado1.Apellido,
                                    empleado1.Sueldo)
    End Sub

    Private Sub DataGridView1_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles DataGridView1.CellContentClick

    End Sub
End Class
