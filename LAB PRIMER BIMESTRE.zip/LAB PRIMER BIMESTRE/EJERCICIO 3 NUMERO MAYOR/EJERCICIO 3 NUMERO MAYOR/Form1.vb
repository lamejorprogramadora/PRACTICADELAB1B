﻿Public Class Form1
    Private Sub Label1_Click(sender As Object, e As EventArgs) Handles Label1.Click

    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim a As Integer
        Dim b As Integer
        Dim c As Integer
        Dim d As Integer
        a = TextBox1.Text
        b = TextBox2.Text
        c = TextBox3.Text

        If (a > b) And (a > c) Then
            d = a

        End If

        If (b > a) And (b > c) Then
            d = b

        End If

        If (c > a) And (c > b) Then
            d = c

        End If
        TextBox4.Text = d
    End Sub
End Class
